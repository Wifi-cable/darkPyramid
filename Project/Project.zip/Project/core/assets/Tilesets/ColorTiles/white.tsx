<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="white" tilewidth="40" tileheight="40" tilecount="4488" columns="68">
 <image source="white.png" width="2736" height="2644"/>
</tileset>
